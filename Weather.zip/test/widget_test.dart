import 'package:flutter_test/flutter_test.dart';
import 'package:skycast/utils/weather_helpers.dart';

void main() {
  test('weather codes are converted to readable descriptions', () {
    expect(weatherDescription(0), 'Clear sky');
    expect(weatherDescription(61), 'Rain');
    expect(weatherDescription(95), 'Thunderstorm');
  });
}
