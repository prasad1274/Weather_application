import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/weather.dart';
import '../services/weather_service.dart';

class WeatherProvider extends ChangeNotifier {
  final WeatherService _service = WeatherService();
  Weather? currentWeather;
  final List<Weather> savedCities = [];
  bool isLoading = false;
  String? error;
  bool isCelsius = true;

  String get temperatureUnit => isCelsius ? '°C' : '°F';
  double displayTemperature(double value) => isCelsius ? value : (value * 9 / 5) + 32;
  String formatTemperature(double value) => '${displayTemperature(value).round()}$temperatureUnit';

  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    isCelsius = prefs.getBool('isCelsius') ?? true;
    final names = prefs.getStringList('savedCities') ?? [];
    for (final name in names) {
      try {
        final weather = await _service.searchWeather(name);
        if (!savedCities.any((w) => w.city.toLowerCase() == weather.city.toLowerCase())) {
          savedCities.add(weather);
        }
      } catch (_) {}
    }
    if (savedCities.isNotEmpty) {
      currentWeather = savedCities.first;
    } else {
      await searchCity('Visakhapatnam');
    }
    notifyListeners();
  }

  Future<bool> searchCity(String query) async {
    final trimmed = query.trim();
    if (trimmed.isEmpty) {
      error = 'Please enter a city name.';
      notifyListeners();
      return false;
    }
    isLoading = true;
    error = null;
    notifyListeners();
    try {
      currentWeather = await _service.searchWeather(trimmed);
      isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      error = e.toString().replaceFirst('Exception: ', '');
      isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> addSavedCity(Weather weather) async {
    if (!savedCities.any((w) => w.city.toLowerCase() == weather.city.toLowerCase())) {
      savedCities.add(weather);
      await _saveNames();
      notifyListeners();
    }
  }

  Future<void> removeSavedCity(String city) async {
    savedCities.removeWhere((w) => w.city.toLowerCase() == city.toLowerCase());
    await _saveNames();
    notifyListeners();
  }

  Future<void> _saveNames() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('savedCities', savedCities.map((w) => w.city).toList());
  }

  Future<void> setCelsius(bool value) async {
    isCelsius = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isCelsius', value);
    notifyListeners();
  }
}
