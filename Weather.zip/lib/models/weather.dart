class Weather {
  final String city;
  final String country;
  final double latitude;
  final double longitude;
  final double temperature;
  final double feelsLike;
  final int humidity;
  final double windSpeed;
  final int weatherCode;
  final bool isDay;
  final List<DailyForecast> daily;

  const Weather({
    required this.city,
    required this.country,
    required this.latitude,
    required this.longitude,
    required this.temperature,
    required this.feelsLike,
    required this.humidity,
    required this.windSpeed,
    required this.weatherCode,
    required this.isDay,
    required this.daily,
  });

  factory Weather.fromApi({
    required String city,
    required String country,
    required double latitude,
    required double longitude,
    required Map<String, dynamic> json,
  }) {
    final current = json['current'];
    final hourly = json['hourly'];
    final dailyJson = json['daily'];
    final time = current['time'] as String;
    final times = List<String>.from(hourly['time'] as List);
    int closest = times.indexOf(time);
    if (closest < 0) closest = 0;
    final apparent = (hourly['apparent_temperature'] as List)[closest];
    final daily = <DailyForecast>[];
    for (var i = 0; i < (dailyJson['time'] as List).length; i++) {
      daily.add(DailyForecast(
        date: DateTime.parse(dailyJson['time'][i] as String),
        min: (dailyJson['temperature_2m_min'][i] as num).toDouble(),
        max: (dailyJson['temperature_2m_max'][i] as num).toDouble(),
        code: dailyJson['weather_code'][i] as int,
      ));
    }
    return Weather(
      city: city,
      country: country,
      latitude: latitude,
      longitude: longitude,
      temperature: (current['temperature_2m'] as num).toDouble(),
      feelsLike: (apparent as num).toDouble(),
      humidity: current['relative_humidity_2m'] as int,
      windSpeed: (current['wind_speed_10m'] as num).toDouble(),
      weatherCode: current['weather_code'] as int,
      isDay: (current['is_day'] as int) == 1,
      daily: daily,
    );
  }
}

class DailyForecast {
  final DateTime date;
  final double min;
  final double max;
  final int code;
  const DailyForecast({required this.date, required this.min, required this.max, required this.code});
}

class CityLocation {
  final String name;
  final String country;
  final double latitude;
  final double longitude;
  const CityLocation({required this.name, required this.country, required this.latitude, required this.longitude});
}
