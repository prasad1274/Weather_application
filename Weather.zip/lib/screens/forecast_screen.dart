import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../models/weather.dart';
import '../providers/weather_provider.dart';
import '../utils/weather_helpers.dart';

class ForecastScreen extends StatelessWidget {
  final Weather weather;
  const ForecastScreen({super.key, required this.weather});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<WeatherProvider>();
    return Scaffold(
      appBar: AppBar(title: Text('${weather.city} forecast')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Text('7-day forecast', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text('Daily weather outlook for ${weather.city}, ${weather.country}.'),
        const SizedBox(height: 16),
        ...weather.daily.asMap().entries.map((entry) {
          final day = entry.value;
          return Card(
            margin: const EdgeInsets.only(bottom: 10),
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
              leading: Icon(weatherIcon(day.code), size: 30, color: Theme.of(context).colorScheme.primary),
              title: Text(entry.key == 0 ? 'Today' : DateFormat('EEEE').format(day.date), style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(weatherDescription(day.code)),
              trailing: Text('${provider.formatTemperature(day.max)} / ${provider.formatTemperature(day.min)}', style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
          );
        }),
      ]),
    );
  }
}
