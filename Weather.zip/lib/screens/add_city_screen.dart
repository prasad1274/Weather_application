import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/weather_provider.dart';

class AddCityScreen extends StatefulWidget {
  const AddCityScreen({super.key});
  @override
  State<AddCityScreen> createState() => _AddCityScreenState();
}

class _AddCityScreenState extends State<AddCityScreen> {
  final formKey = GlobalKey<FormState>();
  final controller = TextEditingController();
  bool submitting = false;

  @override
  void dispose() { controller.dispose(); super.dispose(); }

  Future<void> submit() async {
    if (!formKey.currentState!.validate()) return;
    setState(() => submitting = true);
    final provider = context.read<WeatherProvider>();
    final ok = await provider.searchCity(controller.text);
    if (!mounted) return;
    setState(() => submitting = false);
    if (ok && provider.currentWeather != null) {
      await provider.addSavedCity(provider.currentWeather!);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('City saved successfully.')));
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(provider.error ?? 'Unable to find city.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add a city')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: formKey,
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('Search and save a city', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Enter a city name to get its latest weather and add it to your saved locations.'),
            const SizedBox(height: 22),
            TextFormField(
              controller: controller,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(labelText: 'City name', hintText: 'e.g. Hyderabad', prefixIcon: Icon(Icons.location_city)),
              validator: (value) {
                if (value == null || value.trim().isEmpty) return 'Please enter a city name.';
                if (value.trim().length < 2) return 'City name must contain at least 2 characters.';
                if (value.trim().length > 60) return 'City name must be under 60 characters.';
                if (!RegExp(r"^[a-zA-ZÀ-ÿ .'-]+$").hasMatch(value.trim())) return 'Use letters, spaces, apostrophes or hyphens only.';
                return null;
              },
              onFieldSubmitted: (_) => submitting ? null : submit(),
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: submitting ? null : submit,
              icon: submitting ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.add),
              label: Text(submitting ? 'Searching...' : 'Find and save city'),
            ),
          ]),
        ),
      ),
    );
  }
}
