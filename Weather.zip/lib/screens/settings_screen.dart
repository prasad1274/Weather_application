import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/weather_provider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<WeatherProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Settings', style: TextStyle(fontWeight: FontWeight.bold))),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        const Text('Preferences', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 14),
        Card(child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Temperature unit', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            const Text('Choose how temperatures are displayed throughout SkyCast.'),
            const SizedBox(height: 12),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: true, label: Text('Celsius °C'), icon: Icon(Icons.thermostat)),
                ButtonSegment(value: false, label: Text('Fahrenheit °F'), icon: Icon(Icons.device_thermostat)),
              ],
              selected: {provider.isCelsius},
              onSelectionChanged: (values) => provider.setCelsius(values.first),
            ),
          ]),
        )),
        const SizedBox(height: 18),
        const Card(child: ListTile(
          leading: Icon(Icons.cloud_outlined),
          title: Text('Weather data'),
          subtitle: Text('Powered by Open-Meteo API'),
        )),
        const Card(child: ListTile(
          leading: Icon(Icons.info_outline),
          title: Text('About SkyCast'),
          subtitle: Text('A Flutter weather forecast student project.'),
        )),
      ]),
    );
  }
}
