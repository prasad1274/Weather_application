import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/weather_provider.dart';
import '../utils/weather_helpers.dart';
import '../widgets/weather_stat_card.dart';
import 'add_city_screen.dart';
import 'forecast_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final searchController = TextEditingController();

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<WeatherProvider>();
    final weather = provider.currentWeather;
    return Scaffold(
      appBar: AppBar(
        title: const Text('SkyCast', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [IconButton(tooltip: 'Add a saved city', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddCityScreen())), icon: const Icon(Icons.add_location_alt_outlined))],
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async { if (weather != null) await provider.searchCity(weather.city); },
          child: ListView(padding: const EdgeInsets.all(18), children: [
            Text('Find your weather', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Form(
              child: Row(children: [
                Expanded(child: TextFormField(
                  controller: searchController,
                  textInputAction: TextInputAction.search,
                  decoration: const InputDecoration(hintText: 'Enter city name', prefixIcon: Icon(Icons.search)),
                  onFieldSubmitted: (_) => provider.searchCity(searchController.text),
                )),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: provider.isLoading ? null : () => provider.searchCity(searchController.text),
                  style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18)),
                  child: const Icon(Icons.arrow_forward),
                ),
              ]),
            ),
            const SizedBox(height: 20),
            if (provider.isLoading) const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator())),
            if (!provider.isLoading && provider.error != null)
              Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
                const Icon(Icons.cloud_off, size: 42, color: Colors.orange),
                const SizedBox(height: 8),
                Text(provider.error!, textAlign: TextAlign.center),
                const SizedBox(height: 12),
                OutlinedButton.icon(onPressed: () => provider.searchCity(searchController.text.isEmpty ? (weather?.city ?? 'Visakhapatnam') : searchController.text), icon: const Icon(Icons.refresh), label: const Text('Retry')),
              ]))),
            if (!provider.isLoading && provider.error == null && weather == null)
              const Card(child: Padding(padding: EdgeInsets.all(24), child: Text('No weather data yet. Search for a city to begin.', textAlign: TextAlign.center))),
            if (!provider.isLoading && weather != null) ...[
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF2563EB), Color(0xFF60A5FA)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                  borderRadius: BorderRadius.circular(26),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${weather.city}, ${weather.country}', style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 18),
                  Row(children: [
                    Icon(weatherIcon(weather.weatherCode, isDay: weather.isDay), color: Colors.white, size: 66),
                    const SizedBox(width: 16),
                    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(provider.formatTemperature(weather.temperature), style: const TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold)),
                      Text(weatherDescription(weather.weatherCode), style: const TextStyle(color: Colors.white, fontSize: 16)),
                    ]),
                  ]),
                  const SizedBox(height: 12),
                  Text('Feels like ${provider.formatTemperature(weather.feelsLike)}', style: const TextStyle(color: Colors.white70)),
                  const SizedBox(height: 18),
                  Row(children: [
                    Expanded(child: OutlinedButton.icon(
                      onPressed: () => provider.addSavedCity(weather),
                      icon: const Icon(Icons.bookmark_add_outlined, color: Colors.white),
                      label: const Text('Save city', style: TextStyle(color: Colors.white)),
                      style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.white70)),
                    )),
                    const SizedBox(width: 10),
                    Expanded(child: FilledButton.tonalIcon(
                      onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ForecastScreen(weather: weather))),
                      icon: const Icon(Icons.calendar_month),
                      label: const Text('Forecast'),
                    )),
                  ]),
                ]),
              ),
              const SizedBox(height: 22),
              Text('Today’s highlights', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                childAspectRatio: 1.45,
                children: [
                  WeatherStatCard(icon: Icons.water_drop_outlined, label: 'Humidity', value: '${weather.humidity}%'),
                  WeatherStatCard(icon: Icons.air, label: 'Wind speed', value: '${weather.windSpeed.toStringAsFixed(1)} km/h'),
                  WeatherStatCard(icon: Icons.thermostat, label: 'Feels like', value: provider.formatTemperature(weather.feelsLike)),
                  WeatherStatCard(icon: Icons.location_on_outlined, label: 'Coordinates', value: '${weather.latitude.toStringAsFixed(1)}, ${weather.longitude.toStringAsFixed(1)}'),
                ],
              ),
            ],
          ]),
        ),
      ),
    );
  }
}
