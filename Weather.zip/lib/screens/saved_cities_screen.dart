import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/weather_provider.dart';
import '../utils/weather_helpers.dart';
import 'forecast_screen.dart';

class SavedCitiesScreen extends StatelessWidget {
  const SavedCitiesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<WeatherProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Saved cities', style: TextStyle(fontWeight: FontWeight.bold))),
      body: provider.savedCities.isEmpty
          ? Center(child: Padding(
              padding: const EdgeInsets.all(28),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.bookmark_border, size: 60, color: Colors.blueGrey),
                const SizedBox(height: 12),
                const Text('No saved cities yet', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                const Text('Search for a city and tap Save city to keep it here.', textAlign: TextAlign.center),
              ]),
            ))
          : ListView.builder(
              padding: const EdgeInsets.all(14),
              itemCount: provider.savedCities.length,
              itemBuilder: (context, index) {
                final weather = provider.savedCities[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    onTap: () {
                      provider.searchCity(weather.city);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => ForecastScreen(weather: weather)));
                    },
                    leading: CircleAvatar(child: Icon(weatherIcon(weather.weatherCode, isDay: weather.isDay))),
                    title: Text(weather.city, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('${weather.country} • ${weatherDescription(weather.weatherCode)}'),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text(provider.formatTemperature(weather.temperature), style: const TextStyle(fontWeight: FontWeight.bold)),
                      IconButton(
                        tooltip: 'Remove ${weather.city}',
                        onPressed: () => provider.removeSavedCity(weather.city),
                        icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                      ),
                    ]),
                  ),
                );
              },
            ),
    );
  }
}
