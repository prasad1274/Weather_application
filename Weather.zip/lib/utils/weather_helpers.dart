import 'package:flutter/material.dart';

String weatherDescription(int code) {
  if (code == 0) return 'Clear sky';
  if ([1, 2, 3].contains(code)) return 'Partly cloudy';
  if ([45, 48].contains(code)) return 'Foggy';
  if ([51, 53, 55, 56, 57].contains(code)) return 'Drizzle';
  if ([61, 63, 65, 66, 67].contains(code)) return 'Rain';
  if ([71, 73, 75, 77].contains(code)) return 'Snow';
  if ([80, 81, 82].contains(code)) return 'Rain showers';
  if ([85, 86].contains(code)) return 'Snow showers';
  if ([95, 96, 99].contains(code)) return 'Thunderstorm';
  return 'Weather conditions';
}

IconData weatherIcon(int code, {bool isDay = true}) {
  if (code == 0) return isDay ? Icons.wb_sunny_rounded : Icons.nightlight_round;
  if ([1, 2, 3].contains(code)) return Icons.cloud_rounded;
  if ([45, 48].contains(code)) return Icons.foggy;
  if ([51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82].contains(code)) return Icons.umbrella_rounded;
  if ([71, 73, 75, 77, 85, 86].contains(code)) return Icons.ac_unit_rounded;
  if ([95, 96, 99].contains(code)) return Icons.thunderstorm_rounded;
  return Icons.cloud_queue_rounded;
}
