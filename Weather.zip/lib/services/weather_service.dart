import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/weather.dart';

class WeatherService {
  Future<CityLocation> findCity(String query) async {
    final uri = Uri.https('geocoding-api.open-meteo.com', '/v1/search', {
      'name': query,
      'count': '1',
      'language': 'en',
      'format': 'json',
    });
    final response = await http.get(uri).timeout(const Duration(seconds: 15));
    if (response.statusCode != 200) throw Exception('Could not search for this city. Please try again.');
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final results = data['results'] as List?;
    if (results == null || results.isEmpty) throw Exception('City not found. Check the spelling and try again.');
    final item = results.first as Map<String, dynamic>;
    return CityLocation(
      name: item['name'] as String,
      country: (item['country'] as String?) ?? '',
      latitude: (item['latitude'] as num).toDouble(),
      longitude: (item['longitude'] as num).toDouble(),
    );
  }

  Future<Weather> getWeather(CityLocation city) async {
    final uri = Uri.https('api.open-meteo.com', '/v1/forecast', {
      'latitude': city.latitude.toString(),
      'longitude': city.longitude.toString(),
      'current': 'temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m',
      'hourly': 'apparent_temperature',
      'daily': 'weather_code,temperature_2m_max,temperature_2m_min',
      'timezone': 'auto',
      'forecast_days': '7',
    });
    final response = await http.get(uri).timeout(const Duration(seconds: 15));
    if (response.statusCode != 200) throw Exception('Weather service is unavailable. Please retry.');
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return Weather.fromApi(
      city: city.name,
      country: city.country,
      latitude: city.latitude,
      longitude: city.longitude,
      json: data,
    );
  }

  Future<Weather> searchWeather(String query) async {
    final city = await findCity(query);
    return getWeather(city);
  }
}
