# SkyCast – Weather Forecast App

A Flutter Android weather application built with Dart, Provider, Open-Meteo, HTTP and SharedPreferences.

## Features
- Search for current weather by city.
- Current temperature, feels-like temperature, humidity and wind speed.
- Seven-day weather forecast.
- Save and remove cities.
- Celsius/Fahrenheit preference persisted on the device.
- Loading, error, retry and empty states.
- Validated add-city form.

## Requirements
- Flutter 3.35 or newer
- Dart (included with Flutter)
- Android Studio or VS Code
- Internet connection

## Run
1. Extract the project.
2. Open the `skycast_flutter` folder in Android Studio or VS Code.
3. Run `flutter pub get`.
4. Connect an Android phone or start an emulator.
5. Run `flutter run`.

## Run tests
```bash
flutter test
```

## Build release APK
```bash
flutter build apk --release
```
APK output: `build/app/outputs/flutter-apk/app-release.apk`

## API
Open-Meteo:
- Geocoding: https://geocoding-api.open-meteo.com/
- Forecast: https://api.open-meteo.com/

No API key is required for this project. Review the provider's terms and attribution requirements before public distribution.

## Team contribution
Update this section with your actual team details:
- Student 1: [name] – [screens/features]
- Student 2: [name] – [screens/features]
- Student 3: [name] – [screens/features]

## Screenshots
Add at least three screenshots of your running application here before submission.

## Defect log
Record each defect found during testing, reproduction steps, and whether it was fixed.
